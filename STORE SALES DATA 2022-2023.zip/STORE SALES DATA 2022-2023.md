```python
import pandas as pd

# Load the dataset (adjust the file path if needed)
df = pd.read_csv('data.csv')

# View the first few rows
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>item</th>
      <th>store_id</th>
      <th>2023/1</th>
      <th>2023/2</th>
      <th>2023/3</th>
      <th>2023/4</th>
      <th>2023/5</th>
      <th>2023/6</th>
      <th>2023/7</th>
      <th>2023/8</th>
      <th>...</th>
      <th>2022/3</th>
      <th>2022/4</th>
      <th>2022/5</th>
      <th>2022/6</th>
      <th>2022/7</th>
      <th>2022/8</th>
      <th>2022/9</th>
      <th>2022/10</th>
      <th>2022/11</th>
      <th>2022/12</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4.0</td>
      <td>NaN</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>...</td>
      <td>10.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A</td>
      <td>2</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>6.0</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A</td>
      <td>3</td>
      <td>5.0</td>
      <td>10.0</td>
      <td>50.0</td>
      <td>10.0</td>
      <td>30.0</td>
      <td>10.0</td>
      <td>30.0</td>
      <td>15.0</td>
      <td>...</td>
      <td>20.0</td>
      <td>35.0</td>
      <td>20.0</td>
      <td>27.0</td>
      <td>21.0</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>15.0</td>
      <td>15.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A</td>
      <td>4</td>
      <td>20.0</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>NaN</td>
      <td>30.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>40.0</td>
      <td>...</td>
      <td>10.0</td>
      <td>20.0</td>
      <td>10.0</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>NaN</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A</td>
      <td>5</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>NaN</td>
      <td>25.0</td>
      <td>20.0</td>
      <td>10.0</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>...</td>
      <td>10.0</td>
      <td>10.0</td>
      <td>10.0</td>
      <td>10.0</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>5.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 23 columns</p>
</div>




```python
# Check for duplicates
print(f'Duplicates: {df.duplicated().sum()}')

# Remove duplicates if any
df = df.drop_duplicates()

```

    Duplicates: 0
    


```python
df.isnull().sum()
```




    item           0
    store_id       0
    2023/1      4117
    2023/2      3968
    2023/3      3401
    2023/4      2895
    2023/5      4036
    2023/6      4267
    2023/7      3789
    2023/8      4027
    2023/9      4224
    2022/1      4451
    2022/2      4383
    2022/3      4319
    2022/4      3439
    2022/5      3946
    2022/6      3770
    2022/7      4502
    2022/8      4561
    2022/9      4393
    2022/10     3877
    2022/11     3862
    2022/12     4027
    dtype: int64




```python
# Calculate percentage of missing values per column
missing_percent = df.isnull().mean() * 100
missing_percent

```




    item         0.000000
    store_id     0.000000
    2023/1      76.339700
    2023/2      73.576859
    2023/3      63.063230
    2023/4      53.680697
    2023/5      74.837753
    2023/6      79.121083
    2023/7      70.257742
    2023/8      74.670870
    2023/9      78.323753
    2022/1      82.532913
    2022/2      81.272019
    2022/3      80.085296
    2022/4      63.767847
    2022/5      73.168923
    2022/6      69.905433
    2022/7      83.478583
    2022/8      84.572594
    2022/9      81.457445
    2022/10     71.889486
    2022/11     71.611348
    2022/12     74.670870
    dtype: float64




```python
# Drop columns with more than 70% missing data
df_clean = df.drop(columns=missing_percent[missing_percent > 70].index)

```


```python
# Select numeric columns
numeric_cols = df_clean.select_dtypes(include=['float64', 'int64']).columns

# Select non-numeric columns (categorical or text)
non_numeric_cols = df_clean.select_dtypes(exclude=['float64', 'int64']).columns

```


```python
# Impute missing values with median for numeric columns
df_clean[numeric_cols] = df_clean[numeric_cols].fillna(df_clean[numeric_cols].median())

```


```python
# Fill missing values in non-numeric columns with 'Unknown' or another placeholder
df_clean[non_numeric_cols] = df_clean[non_numeric_cols].fillna('Unknown')

```


```python
df_clean.isnull().sum()
```




    item        0
    store_id    0
    2023/3      0
    2023/4      0
    2022/4      0
    2022/6      0
    dtype: int64




```python
#EDA
```


```python
df_clean.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>store_id</th>
      <th>2023/3</th>
      <th>2023/4</th>
      <th>2022/4</th>
      <th>2022/6</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5393.000000</td>
      <td>5393.000000</td>
      <td>5393.000000</td>
      <td>5393.000000</td>
      <td>5393.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>472.825885</td>
      <td>15.166327</td>
      <td>27.122752</td>
      <td>15.309290</td>
      <td>17.870017</td>
    </tr>
    <tr>
      <th>std</th>
      <td>277.945220</td>
      <td>36.186501</td>
      <td>119.583805</td>
      <td>31.352169</td>
      <td>34.212907</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>-13.000000</td>
      <td>-20.000000</td>
      <td>1.000000</td>
      <td>-20.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>233.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>464.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>709.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1032.000000</td>
      <td>1000.000000</td>
      <td>3800.000000</td>
      <td>760.000000</td>
      <td>640.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Check for duplicates
df_clean.duplicated().sum()

# Summary statistics for each column
df_clean.describe()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>store_id</th>
      <th>2023/3</th>
      <th>2023/4</th>
      <th>2022/4</th>
      <th>2022/6</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5393.000000</td>
      <td>5393.000000</td>
      <td>5393.000000</td>
      <td>5393.000000</td>
      <td>5393.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>472.825885</td>
      <td>15.166327</td>
      <td>27.122752</td>
      <td>15.309290</td>
      <td>17.870017</td>
    </tr>
    <tr>
      <th>std</th>
      <td>277.945220</td>
      <td>36.186501</td>
      <td>119.583805</td>
      <td>31.352169</td>
      <td>34.212907</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>-13.000000</td>
      <td>-20.000000</td>
      <td>1.000000</td>
      <td>-20.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>233.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>464.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>709.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>13.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1032.000000</td>
      <td>1000.000000</td>
      <td>3800.000000</td>
      <td>760.000000</td>
      <td>640.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_clean.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 5393 entries, 0 to 5392
    Data columns (total 6 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   item      5393 non-null   object 
     1   store_id  5393 non-null   int64  
     2   2023/3    5393 non-null   float64
     3   2023/4    5393 non-null   float64
     4   2022/4    5393 non-null   float64
     5   2022/6    5393 non-null   float64
    dtypes: float64(4), int64(1), object(1)
    memory usage: 252.9+ KB
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

# Distribution plot for each month's sales
sns.histplot(df_clean['2023/3'], kde=True)
plt.title('Distribution of Sales for March 2023')
plt.show()

# Box plot to check for outliers
sns.boxplot(df_clean['2023/3'])

```


    
![png](output_13_0.png)
    





    <Axes: >




    
![png](output_13_2.png)
    


# Sales Trends Over Time:
sales trends to see how sales are progressing over time.  plot the sum or mean of sales over months.


```python
# Aggregating monthly sales to see trends
monthly_sales = df_clean[['2023/3', '2023/4', '2022/4', '2022/6']].sum()

# Plotting the trend
monthly_sales.plot(kind='line')
plt.title('Sales Trend Over Time')
plt.ylabel('Total Sales')
plt.show()

```


    
![png](output_15_0.png)
    


# Correlation Analysis:

Investigate if there are any correlations between the monthly sales. This will help understand whether the sales data from different months move together.


```python
# Filter numeric columns for correlation analysis
numeric_columns = df_clean.select_dtypes(include=['float64', 'int64'])

# Correlation matrix
correlation_matrix = numeric_columns.corr()

# Heatmap visualization
import seaborn as sns
import matplotlib.pyplot as plt

sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm')
plt.title('Correlation between Monthly Sales')
plt.show()


```


    
![png](output_17_0.png)
    


# Outlier Detection and Handling:

Identify and handle any extreme outliers in the data. For example, extreme sales values might distort analysis.
Decide to cap the outliers or remove them depending on the business context


```python
# Convert relevant columns to numeric (if not already)
df_clean['2023/3'] = pd.to_numeric(df_clean['2023/3'], errors='coerce')
df_clean['2023/4'] = pd.to_numeric(df_clean['2023/4'], errors='coerce')
df_clean['2022/4'] = pd.to_numeric(df_clean['2022/4'], errors='coerce')
df_clean['2022/6'] = pd.to_numeric(df_clean['2022/6'], errors='coerce')

# Create new feature: Difference in sales between March and April 2023
df_clean['sales_diff_2023'] = df_clean['2023/4'] - df_clean['2023/3']

# Create new feature: Difference in sales between April 2022 and June 2022
df_clean['sales_diff_2022'] = df_clean['2022/6'] - df_clean['2022/4']

# Check the new columns
df_clean[['sales_diff_2023', 'sales_diff_2022']].head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sales_diff_2023</th>
      <th>sales_diff_2022</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-40.0</td>
      <td>-8.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-10.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>15.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Summary statistics of sales differences
df_clean[['sales_diff_2023', 'sales_diff_2022']].describe()

# Plot histograms to visualize the distribution of sales differences
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(10, 5))

# Distribution of sales_diff_2023
plt.subplot(1, 2, 1)
sns.histplot(df_clean['sales_diff_2023'], kde=True, bins=30)
plt.title('Distribution of Sales Difference (2023)')

# Distribution of sales_diff_2022
plt.subplot(1, 2, 2)
sns.histplot(df_clean['sales_diff_2022'], kde=True, bins=30)
plt.title('Distribution of Sales Difference (2022)')

plt.tight_layout()
plt.show()

```


    
![png](output_20_0.png)
    



```python
# Boxplot to detect outliers
plt.figure(figsize=(10, 5))

# Boxplot for sales_diff_2023
plt.subplot(1, 2, 1)
sns.boxplot(x=df_clean['sales_diff_2023'])
plt.title('Boxplot of Sales Difference (2023)')

# Boxplot for sales_diff_2022
plt.subplot(1, 2, 2)
sns.boxplot(x=df_clean['sales_diff_2022'])
plt.title('Boxplot of Sales Difference (2022)')

plt.tight_layout()
plt.show()

```


    
![png](output_21_0.png)
    


# Which stores have the highest positive and negative sales differences?


```python
# Stores with the highest positive sales difference in 2023
highest_sales_diff_2023 = df_clean[['store_id', 'sales_diff_2023']].sort_values(by='sales_diff_2023', ascending=False).head()

# Stores with the highest negative sales difference in 2023
lowest_sales_diff_2023 = df_clean[['store_id', 'sales_diff_2023']].sort_values(by='sales_diff_2023', ascending=True).head()

# Stores with the highest positive sales difference in 2022
highest_sales_diff_2022 = df_clean[['store_id', 'sales_diff_2022']].sort_values(by='sales_diff_2022', ascending=False).head()

# Stores with the highest negative sales difference in 2022
lowest_sales_diff_2022 = df_clean[['store_id', 'sales_diff_2022']].sort_values(by='sales_diff_2022', ascending=True).head()

# Display the results
print("Highest Positive Sales Difference in 2023:")
print(highest_sales_diff_2023)

print("\nLowest (Negative) Sales Difference in 2023:")
print(lowest_sales_diff_2023)

print("\nHighest Positive Sales Difference in 2022:")
print(highest_sales_diff_2022)

print("\nLowest (Negative) Sales Difference in 2022:")
print(lowest_sales_diff_2022)

```

    Highest Positive Sales Difference in 2023:
          store_id  sales_diff_2023
    741        742           3000.0
    1619       742           2800.0
    828        829           1917.0
    1697       829           1608.0
    415        416           1500.0
    
    Lowest (Negative) Sales Difference in 2023:
          store_id  sales_diff_2023
    411        412           -530.0
    1767       912           -510.0
    1309       412           -420.0
    428        429           -390.0
    2213       412           -350.0
    
    Highest Positive Sales Difference in 2022:
          store_id  sales_diff_2022
    2230       429            500.0
    428        429            450.0
    1619       742            420.0
    158        159            310.0
    632        633            309.0
    
    Lowest (Negative) Sales Difference in 2022:
          store_id  sales_diff_2022
    3382       742           -487.0
    974         66           -390.0
    2030       225           -347.0
    742        743           -287.0
    2909       225           -287.0
    

# How do sales differences vary across different items and stores?


```python
# Grouping by item and store_id to calculate mean sales differences
sales_diff_by_item_store = df_clean.groupby(['item', 'store_id'])[['sales_diff_2023', 'sales_diff_2022']].mean().reset_index()

```


```python
# Aggregate the data to find overall differences by item
sales_diff_summary = sales_diff_by_item_store.groupby('item')[['sales_diff_2023', 'sales_diff_2022']].mean().reset_index()

# Display the summary
print(sales_diff_summary)

```

      item  sales_diff_2023  sales_diff_2022
    0    A        22.840834         3.034029
    1    B        21.112098         2.438402
    2    C        16.591883         2.391206
    3    D        11.459075         1.444840
    4    E         2.090196         2.831373
    5    F        -0.290553         3.000000
    6    G         0.056198         3.000000
    7    H        -0.302326         3.000000
    


```python
import matplotlib.pyplot as plt
import seaborn as sns

# Set the figure size
plt.figure(figsize=(12, 6))

# Create a bar plot for sales differences by item
sns.barplot(data=sales_diff_summary, x='item', y='sales_diff_2023', color='gray', label='2023')
sns.barplot(data=sales_diff_summary, x='item', y='sales_diff_2022', color='orange', label='2022', alpha=0.6)

# Add labels and title
plt.title('Average Sales Differences by Item')
plt.xlabel('Item')
plt.ylabel('Average Sales Difference')
plt.xticks(rotation=45)
plt.legend()

# Show the plot
plt.tight_layout()
plt.show()

```


    
![png](output_27_0.png)
    


# Product insights: identify the product sales analysis, such as BCG matrix


```python
# Calculate total sales for each product
total_sales = df_clean.groupby('item')[['sales_diff_2023', 'sales_diff_2022']].sum().reset_index()

# Calculate market share for each product
total_sales['market_share'] = total_sales['sales_diff_2023'] / total_sales['sales_diff_2023'].sum()

# Calculate year-over-year growth (2023 vs 2022)
total_sales['market_growth'] = (total_sales['sales_diff_2023'] - total_sales['sales_diff_2022']) / total_sales['sales_diff_2022'] * 100

# Display the total sales DataFrame
print(total_sales)

```

      item  sales_diff_2023  sales_diff_2022  market_share  market_growth
    0    A          20808.0           2764.0      0.322700     652.821997
    1    B          19022.0           2197.0      0.295002     765.817023
    2    C          14717.0           2121.0      0.228238     593.870816
    3    D           9660.0           1218.0      0.149812     693.103448
    4    E            533.0            722.0      0.008266     -26.177285
    5    F           -163.0           1683.0     -0.002528    -109.685086
    6    G             34.0           1815.0      0.000527     -98.126722
    7    H           -130.0           1290.0     -0.002016    -110.077519
    


```python
# Define thresholds
market_growth_threshold = total_sales['market_growth'].median()
market_share_threshold = total_sales['market_share'].median()

# Classify products based on thresholds
def classify_product(row):
    if row['market_growth'] >= market_growth_threshold and row['market_share'] >= market_share_threshold:
        return 'Star'
    elif row['market_growth'] < market_growth_threshold and row['market_share'] >= market_share_threshold:
        return 'Cash Cow'
    elif row['market_growth'] >= market_growth_threshold and row['market_share'] < market_share_threshold:
        return 'Question Mark'
    else:
        return 'Dog'

total_sales['BCG_Category'] = total_sales.apply(classify_product, axis=1)

# Display classified products
print(total_sales[['item', 'market_share', 'market_growth', 'BCG_Category']])

```

      item  market_share  market_growth BCG_Category
    0    A      0.322700     652.821997         Star
    1    B      0.295002     765.817023         Star
    2    C      0.228238     593.870816         Star
    3    D      0.149812     693.103448         Star
    4    E      0.008266     -26.177285          Dog
    5    F     -0.002528    -109.685086          Dog
    6    G      0.000527     -98.126722          Dog
    7    H     -0.002016    -110.077519          Dog
    


```python
import matplotlib.pyplot as plt

# Create a scatter plot
plt.figure(figsize=(10, 6))

# Scatter plot for market share vs market growth
sns.scatterplot(data=total_sales, x='market_share', y='market_growth', hue='BCG_Category', style='BCG_Category', s=100)

# Adding titles and labels
plt.axhline(y=market_growth_threshold, color='r', linestyle='--', label='Market Growth Threshold')
plt.axvline(x=market_share_threshold, color='g', linestyle='--', label='Market Share Threshold')
plt.title('BCG Matrix')
plt.xlabel('Market Share')
plt.ylabel('Market Growth (%)')
plt.legend()
plt.grid()

# Show plot
plt.tight_layout()
plt.show()

```


    
![png](output_31_0.png)
    


# CONCLUSION
The BCG Matrix helps you visualize which products are performing well and which ones need attention or resources. By strategically analyzing your product portfolio using this matrix, you can make informed decisions about where to focus your efforts for growth and profitability.

# Store insights: identify the sales performance of the sales


```python
# Aggregate sales data by store
store_sales = df_clean.groupby('store_id')[['sales_diff_2023', 'sales_diff_2022']].sum().reset_index()

# Calculate average sales for each store
store_sales['avg_sales_2023'] = store_sales['sales_diff_2023'] / 12  # Assuming 12 months for 2023
store_sales['avg_sales_2022'] = store_sales['sales_diff_2022'] / 12  # Assuming 12 months for 2022

# Display store sales DataFrame
print(store_sales)

```

          store_id  sales_diff_2023  sales_diff_2022  avg_sales_2023  \
    0            1             20.0             12.0        1.666667   
    1            2             10.0             10.0        0.833333   
    2            3            -84.0            -14.0       -7.000000   
    3            4            -20.0             13.0       -1.666667   
    4            5             10.0              0.0        0.833333   
    ...        ...              ...              ...             ...   
    1027      1028              0.0              3.0        0.000000   
    1028      1029              0.0              3.0        0.000000   
    1029      1030              0.0              3.0        0.000000   
    1030      1031              0.0              3.0        0.000000   
    1031      1032              0.0              3.0        0.000000   
    
          avg_sales_2022  
    0           1.000000  
    1           0.833333  
    2          -1.166667  
    3           1.083333  
    4           0.000000  
    ...              ...  
    1027        0.250000  
    1028        0.250000  
    1029        0.250000  
    1030        0.250000  
    1031        0.250000  
    
    [1032 rows x 5 columns]
    


```python
# Calculate year-over-year growth for each store
store_sales['growth_rate'] = (store_sales['sales_diff_2023'] - store_sales['sales_diff_2022']) / store_sales['sales_diff_2022'] * 100

# Display updated store sales DataFrame
print(store_sales[['store_id', 'sales_diff_2023', 'sales_diff_2022', 'growth_rate']])

```

          store_id  sales_diff_2023  sales_diff_2022  growth_rate
    0            1             20.0             12.0    66.666667
    1            2             10.0             10.0     0.000000
    2            3            -84.0            -14.0   500.000000
    3            4            -20.0             13.0  -253.846154
    4            5             10.0              0.0          inf
    ...        ...              ...              ...          ...
    1027      1028              0.0              3.0  -100.000000
    1028      1029              0.0              3.0  -100.000000
    1029      1030              0.0              3.0  -100.000000
    1030      1031              0.0              3.0  -100.000000
    1031      1032              0.0              3.0  -100.000000
    
    [1032 rows x 4 columns]
    


```python
# Identify top and bottom performing stores based on 2023 sales
top_stores = store_sales.nlargest(5, 'sales_diff_2023')
bottom_stores = store_sales.nsmallest(5, 'sales_diff_2023')

print("Top Performing Stores:")
print(top_stores)

print("\nBottom Performing Stores:")
print(bottom_stores)

```

    Top Performing Stores:
         store_id  sales_diff_2023  sales_diff_2022  avg_sales_2023  \
    741       742           8390.0            -45.0      699.166667   
    828       829           5420.0             29.0      451.666667   
    794       795           4870.0             21.0      405.833333   
    415       416           3916.0             42.0      326.333333   
    742       743           2880.0            -22.0      240.000000   
    
         avg_sales_2022   growth_rate  
    741       -3.750000 -18744.444444  
    828        2.416667  18589.655172  
    794        1.750000  23090.476190  
    415        3.500000   9223.809524  
    742       -1.833333 -13190.909091  
    
    Bottom Performing Stores:
         store_id  sales_diff_2023  sales_diff_2022  avg_sales_2023  \
    411       412          -1585.0           -482.0     -132.083333   
    911       912           -510.0           -264.0      -42.500000   
    417       418           -490.0           -328.0      -40.833333   
    556       557           -455.0            150.0      -37.916667   
    7           8           -300.0            -44.0      -25.000000   
    
         avg_sales_2022  growth_rate  
    411      -40.166667   228.838174  
    911      -22.000000    93.181818  
    417      -27.333333    49.390244  
    556       12.500000  -403.333333  
    7         -3.666667   581.818182  
    


```python
import matplotlib.pyplot as plt
import seaborn as sns
#Visualization: Total Sales by Store
# Set the style for the plots
sns.set(style="whitegrid")

# Plot total sales by store
plt.figure(figsize=(12, 6))
sns.barplot(x='store_id', y='sales_diff_2023', data=store_sales, palette='viridis')
plt.title('Total Sales by Store in 2023')
plt.xlabel('Store ID')
plt.ylabel('Total Sales')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

```


    
![png](output_37_0.png)
    



```python
# Plot growth rates by store
#Visualization: Growth Rate by Store

plt.figure(figsize=(12, 6))
sns.barplot(x='store_id', y='growth_rate', data=store_sales, palette='coolwarm')
plt.title('Year-over-Year Sales Growth Rate by Store')
plt.xlabel('Store ID')
plt.ylabel('Growth Rate (%)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

```


    
![png](output_38_0.png)
    


# Supply chain insights: identify the demand


```python
# Assuming 'item' column represents the product, and you have a sales column
demand_data = df_clean.groupby('item')[['sales_diff_2023', 'sales_diff_2022']].sum().reset_index()

# Rename columns for clarity
demand_data.columns = ['item', 'total_demand_2023', 'total_demand_2022']

```


```python
# Calculate year-over-year demand change
demand_data['demand_change'] = demand_data['total_demand_2023'] - demand_data['total_demand_2022']

# Calculate percentage change
demand_data['percent_change'] = (demand_data['demand_change'] / demand_data['total_demand_2022']) * 100

```


```python
# Identify high demand products
high_demand_products = demand_data.nlargest(5, 'total_demand_2023')

# Identify low demand products
low_demand_products = demand_data.nsmallest(5, 'total_demand_2023')

print("High Demand Products:")
print(high_demand_products)

print("\nLow Demand Products:")
print(low_demand_products)

```

    High Demand Products:
      item  total_demand_2023  total_demand_2022  demand_change  percent_change
    0    A            20808.0             2764.0        18044.0      652.821997
    1    B            19022.0             2197.0        16825.0      765.817023
    2    C            14717.0             2121.0        12596.0      593.870816
    3    D             9660.0             1218.0         8442.0      693.103448
    4    E              533.0              722.0         -189.0      -26.177285
    
    Low Demand Products:
      item  total_demand_2023  total_demand_2022  demand_change  percent_change
    5    F             -163.0             1683.0        -1846.0     -109.685086
    7    H             -130.0             1290.0        -1420.0     -110.077519
    6    G               34.0             1815.0        -1781.0      -98.126722
    4    E              533.0              722.0         -189.0      -26.177285
    3    D             9660.0             1218.0         8442.0      693.103448
    

# Visualization: Total Demand by Item


```python
import matplotlib.pyplot as plt
import seaborn as sns

# Set the style for the plots
sns.set(style="whitegrid")

# Plot total demand by item
plt.figure(figsize=(12, 6))
sns.barplot(x='item', y='total_demand_2023', data=demand_data, palette='rocket')
plt.title('Total Demand by Item in 2023')
plt.xlabel('Item')
plt.ylabel('Total Demand')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

```


    
![png](output_44_0.png)
    


# Visualization: Year-over-Year Demand Change


```python
# Plot year-over-year demand change
plt.figure(figsize=(12, 6))
sns.barplot(x='item', y='percent_change', data=demand_data, palette='magma')
plt.title('Year-over-Year Demand Change by Item')
plt.xlabel('Item')
plt.ylabel('Percentage Change (%)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

```


    
![png](output_46_0.png)
    


# Analyze Seasonality in Demand


```python
# Reshape data for seasonal analysis (if applicable)
seasonal_demand = df_clean.groupby(['item', 'store_id']).sum().reset_index()

# Pivot table to see monthly demand for each item
monthly_demand = seasonal_demand.pivot_table(index='item', columns='store_id', values='sales_diff_2023', aggfunc='sum')

# Optionally visualize this monthly demand if the data is available over time

```

# Time series forecasting: identify tread, seasonality


```python
# Check the current columns in df_clean
print(df_clean.columns)

# Identify the columns you want to melt (exclude sales_diff columns)
date_columns = ['2023/3', '2023/4', '2022/4', '2022/6']

# Reshape your DataFrame, only keeping item, store_id, and the relevant date columns
melted_df = df_clean.melt(id_vars=['item', 'store_id'], value_vars=date_columns, var_name='date', value_name='sales')

# Convert the 'date' column to datetime format
melted_df['date'] = pd.to_datetime(melted_df['date'], format='%Y/%m')

# Aggregate sales data by month
monthly_sales = melted_df.groupby('date')['sales'].sum().reset_index()

# Display the aggregated monthly sales
print(monthly_sales.head())

```

    Index(['item', 'store_id', '2023/3', '2023/4', '2022/4', '2022/6',
           'sales_diff_2023', 'sales_diff_2022'],
          dtype='object')
            date     sales
    0 2022-04-01   82563.0
    1 2022-06-01   96373.0
    2 2023-03-01   81792.0
    3 2023-04-01  146273.0
    


```python
plt.figure(figsize=(14, 7))
sns.lineplot(data=monthly_sales, x='date', y='sales', marker='o', color='blue')
plt.title('Total Monthly Sales Over Time')
plt.xlabel('Date')
plt.ylabel('Total Sales')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

```


    
![png](output_51_0.png)
    



```python
import statsmodels.api as sm
import matplotlib.pyplot as plt

# Check the structure of monthly_sales
print(monthly_sales.head())
print(monthly_sales.columns)

# If the 'date' column is missing, make sure to create monthly_sales correctly before this step
# Assuming monthly_sales is meant to be a DataFrame with date and sales

# Set the index correctly if date column exists
if 'date' in monthly_sales.columns:
    monthly_sales.set_index('date', inplace=True)
    monthly_sales = monthly_sales.asfreq('M')  # Set frequency to month-end

    # Decompose the time series
    decomposition = sm.tsa.seasonal_decompose(monthly_sales['sales'], model='additive')

    # Plot the decomposition
    plt.figure(figsize=(14, 10))
    decomposition.plot()
    plt.tight_layout()
    plt.show()
else:
    print("The 'date' column is not in the monthly_sales DataFrame.")


```

            date     sales
    0 2022-04-01   82563.0
    1 2022-06-01   96373.0
    2 2023-03-01   81792.0
    3 2023-04-01  146273.0
    Index(['date', 'sales'], dtype='object')
    


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[155], line 17
         14 monthly_sales = monthly_sales.asfreq('M')  # Set frequency to month-end
         16 # Decompose the time series
    ---> 17 decomposition = sm.tsa.seasonal_decompose(monthly_sales['sales'], model='additive')
         19 # Plot the decomposition
         20 plt.figure(figsize=(14, 10))
    

    File ~\anaconda3\Lib\site-packages\statsmodels\tsa\seasonal.py:153, in seasonal_decompose(x, model, filt, period, two_sided, extrapolate_trend)
        150 nobs = len(x)
        152 if not np.all(np.isfinite(x)):
    --> 153     raise ValueError("This function does not handle missing values")
        154 if model.startswith("m"):
        155     if np.any(x <= 0):
    

    ValueError: This function does not handle missing values



```python
# Identify the date columns in df_clean
# Assuming the dates are the columns from 2022 and 2023
date_columns = ['2022/4', '2022/6', '2023/3', '2023/4']  # Adjust this list based on your DataFrame

# Reshape your DataFrame
melted_df = df_clean.melt(id_vars=['item', 'store_id'], value_vars=date_columns, var_name='date', value_name='sales')

# Convert the 'date' column to datetime format
melted_df['date'] = pd.to_datetime(melted_df['date'], format='%Y/%m')

# Aggregate sales data by month
monthly_sales = melted_df.groupby('date')['sales'].sum().reset_index()

# Print the monthly_sales DataFrame to check
print(monthly_sales.head())

```


```python
melted_df['date'] = pd.to_datetime(melted_df['date'], format='%Y/%m')

```


```python
monthly_sales = melted_df.groupby('date')['sales'].sum().reset_index()

```


```python
monthly_sales.set_index('date', inplace=True)
monthly_sales = monthly_sales.asfreq('M')  # Set frequency to month-end

```


```python
print(monthly_sales.isnull().sum())

```


```python
monthly_sales.dropna(inplace=True)

```


```python
monthly_sales['sales'].fillna(method='ffill', inplace=True)  # Forward fill
# or
monthly_sales['sales'].interpolate(method='linear', inplace=True)  # Linear interpolation

```


```python
print(monthly_sales.head())
print(monthly_sales.columns)

```


```python
import pandas as pd

# Check the original cleaned DataFrame
print("Original Cleaned DataFrame:")
print(df_clean.head())
print(df_clean.info())

# Reshape your DataFrame if needed
melted_df = df_clean.melt(id_vars=['item', 'store_id'], var_name='date', value_name='sales')

# Check the melted DataFrame
print("Melted DataFrame:")
print(melted_df.head())
print(melted_df.info())

# Aggregate sales data by month
monthly_sales = melted_df.groupby('date')['sales'].sum().reset_index()

# Check the resulting monthly sales DataFrame
print("Monthly Sales DataFrame:")
print(monthly_sales.head())
print(monthly_sales.info())

```

    Original Cleaned DataFrame:
      item  store_id  2023/3  2023/4  2022/4  2022/6  sales_diff_2023  \
    0    A         1     4.0    10.0    10.0    13.0              6.0   
    1    A         2     5.0    10.0     5.0     6.0              5.0   
    2    A         3    50.0    10.0    35.0    27.0            -40.0   
    3    A         4    20.0    10.0    20.0    20.0            -10.0   
    4    A         5    10.0    25.0    10.0    10.0             15.0   
    
       sales_diff_2022  
    0              3.0  
    1              1.0  
    2             -8.0  
    3              0.0  
    4              0.0  
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 5393 entries, 0 to 5392
    Data columns (total 8 columns):
     #   Column           Non-Null Count  Dtype  
    ---  ------           --------------  -----  
     0   item             5393 non-null   object 
     1   store_id         5393 non-null   int64  
     2   2023/3           5393 non-null   float64
     3   2023/4           5393 non-null   float64
     4   2022/4           5393 non-null   float64
     5   2022/6           5393 non-null   float64
     6   sales_diff_2023  5393 non-null   float64
     7   sales_diff_2022  5393 non-null   float64
    dtypes: float64(6), int64(1), object(1)
    memory usage: 337.2+ KB
    None
    Melted DataFrame:
      item  store_id    date  sales
    0    A         1  2023/3    4.0
    1    A         2  2023/3    5.0
    2    A         3  2023/3   50.0
    3    A         4  2023/3   20.0
    4    A         5  2023/3   10.0
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 32358 entries, 0 to 32357
    Data columns (total 4 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   item      32358 non-null  object 
     1   store_id  32358 non-null  int64  
     2   date      32358 non-null  object 
     3   sales     32358 non-null  float64
    dtypes: float64(1), int64(1), object(2)
    memory usage: 1011.3+ KB
    None
    Monthly Sales DataFrame:
                  date     sales
    0           2022/4   82563.0
    1           2022/6   96373.0
    2           2023/3   81792.0
    3           2023/4  146273.0
    4  sales_diff_2022   13810.0
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6 entries, 0 to 5
    Data columns (total 2 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   date    6 non-null      object 
     1   sales   6 non-null      float64
    dtypes: float64(1), object(1)
    memory usage: 228.0+ bytes
    None
    


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm

```


```python
import pandas as pd

# Load your data
data = pd.read_csv('data.csv')  # Replace with your actual file path

# Print the DataFrame to see the structure and column names
print(data.head())  # This will show the first few rows of your DataFrame
print(data.columns)  # This will print out the column names

# Melt the DataFrame to convert from wide to long format
data_melted = data.melt(id_vars=['item', 'store_id'], var_name='date', value_name='sales')

# Convert the date column to datetime format
data_melted['date'] = pd.to_datetime(data_melted['date'].str.replace('/', '-'))

# Set the date column as the index
data_melted.set_index('date', inplace=True)

# Resample the data to monthly frequency and sum the sales
monthly_sales = data_melted.resample('M').sum()  # Adjust based on your needs

#

```

      item  store_id  2023/1  2023/2  2023/3  2023/4  2023/5  2023/6  2023/7  \
    0    A         1     NaN     NaN     4.0     NaN     5.0     NaN     5.0   
    1    A         2     5.0     NaN     5.0     NaN     NaN     NaN     NaN   
    2    A         3     5.0    10.0    50.0    10.0    30.0    10.0    30.0   
    3    A         4    20.0     NaN    20.0     NaN    30.0     0.0     NaN   
    4    A         5     NaN    20.0     NaN    25.0    20.0    10.0     NaN   
    
       2023/8  ...  2022/3  2022/4  2022/5  2022/6  2022/7  2022/8  2022/9  \
    0     NaN  ...    10.0     NaN     NaN     NaN     NaN     NaN     NaN   
    1     5.0  ...     5.0     5.0     NaN     6.0     5.0     NaN     2.0   
    2    15.0  ...    20.0    35.0    20.0    27.0    21.0     NaN    20.0   
    3    40.0  ...    10.0    20.0    10.0    20.0    20.0     NaN    20.0   
    4    20.0  ...    10.0    10.0    10.0    10.0     NaN    20.0     NaN   
    
       2022/10  2022/11  2022/12  
    0      NaN      NaN      NaN  
    1      5.0      NaN      NaN  
    2     15.0     15.0     20.0  
    3     20.0      NaN     10.0  
    4      NaN     20.0      5.0  
    
    [5 rows x 23 columns]
    Index(['item', 'store_id', '2023/1', '2023/2', '2023/3', '2023/4', '2023/5',
           '2023/6', '2023/7', '2023/8', '2023/9', '2022/1', '2022/2', '2022/3',
           '2022/4', '2022/5', '2022/6', '2022/7', '2022/8', '2022/9', '2022/10',
           '2022/11', '2022/12'],
          dtype='object')
    


```python
# Option 1: Drop missing values
monthly_sales.dropna(inplace=True)

# Option 2: Fill missing values
# monthly_sales.fillna(method='ffill', inplace=True)  # Forward fill
# or
# monthly_sales.interpolate(method='linear', inplace=True)  # Linear interpolation

```

# Time series graph of your monthly sales data.

Assuming monthly_sales has a single column named sales, your plotting code should look like this:


```python
print(monthly_sales.head())
print(monthly_sales.index)
plt.figure(figsize=(12, 6))
plt.plot(monthly_sales.index, monthly_sales['sales'], marker='o')  # Ensure you specify the column name
plt.title('Monthly Sales Data')
plt.xlabel('Date')
plt.ylabel('Sales')
plt.grid()
plt.show()

```

                sales
    date             
    2022-04-30    NaN
    2022-05-31    NaN
    2022-06-30    NaN
    2022-07-31    NaN
    2022-08-31    NaN
    DatetimeIndex(['2022-04-30', '2022-05-31', '2022-06-30', '2022-07-31',
                   '2022-08-31', '2022-09-30', '2022-10-31', '2022-11-30',
                   '2022-12-31', '2023-01-31', '2023-02-28', '2023-03-31'],
                  dtype='datetime64[ns]', name='date', freq='M')
    


    
![png](output_66_1.png)
    


# Check Residuals:
It's important to analyze the residuals of the fitted model to ensure that they are approximately normally distributed and exhibit no autocorrelation. You can use plots like the ACF (Autocorrelation Function) and PACF (Partial Autocorrelation Function) plots.


```python
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

# Plot ACF and PACF of the residuals
residuals = model_fit.resid

# Set the number of lags to a value less than 10 (for example, 5)
max_lags = 5  

plt.figure(figsize=(12, 6))

# ACF Plot
plt.subplot(211)
plot_acf(residuals, lags=max_lags, ax=plt.gca())
plt.title('ACF of Residuals')

# PACF Plot
plt.subplot(212)
plot_pacf(residuals, lags=max_lags, ax=plt.gca())

```




    
![png](output_68_0.png)
    




    
![png](output_68_1.png)
    


# Forecasting Future Sales


```python
# Forecasting the next 6 months
forecast_steps = 6
forecast = model_fit.get_forecast(steps=forecast_steps)

# Get the predicted mean and confidence intervals
forecast_mean = forecast.predicted_mean
confidence_intervals = forecast.conf_int()

# Create a DataFrame to hold the forecast
forecast_index = pd.date_range(start=monthly_sales.index[-1] + pd.DateOffset(months=1), periods=forecast_steps, freq='M')
forecast_df = pd.DataFrame({'Forecasted Sales': forecast_mean}, index=forecast_index)

# Plotting the results
plt.figure(figsize=(12, 6))
plt.plot(monthly_sales['sales'], label='Historical Sales', color='blue')
plt.plot(forecast_df['Forecasted Sales'], label='Forecasted Sales', color='orange')
plt.fill_between(forecast_df.index, confidence_intervals.iloc[:, 0], confidence_intervals.iloc[:, 1], color='pink', alpha=0.5)
plt.title('Sales Forecast')
plt.xlabel('Date')
plt.ylabel('Sales')
plt.legend()
plt.show()

```


    
![png](output_70_0.png)
    



```python
print(data.columns)
```

    Index(['item', 'store_id', '2023/1', '2023/2', '2023/3', '2023/4', '2023/5',
           '2023/6', '2023/7', '2023/8', '2023/9', '2022/1', '2022/2', '2022/3',
           '2022/4', '2022/5', '2022/6', '2022/7', '2022/8', '2022/9', '2022/10',
           '2022/11', '2022/12', 'promotion'],
          dtype='object')
    

# A/B testing

# Adding a simulated promotion colum


```python
import numpy as np

# Adding a simulated promotion column (randomly assign 50% to promotion)
np.random.seed(42)  # For reproducibility
data['promotion'] = np.random.choice([0, 1], size=len(data), p=[0.5, 0.5])

# Segment the data into control and test groups
control_group = data[data['promotion'] == 0]
test_group = data[data['promotion'] == 1]

# Verify the segmentation
print(f"Control group sample size: {len(control_group)}")
print(f"Test group sample size: {len(test_group)}")

```

    Control group sample size: 2701
    Test group sample size: 2692
    

# Compare average sales between control and test groups


```python
# Calculate mean sales for control and test groups
control_sales_mean = control_group[['2023/1', '2023/2', '2023/3', '2023/4', '2023/5', 
                                    '2023/6', '2023/7', '2023/8', '2023/9']].mean().mean()

test_sales_mean = test_group[['2023/1', '2023/2', '2023/3', '2023/4', '2023/5', 
                              '2023/6', '2023/7', '2023/8', '2023/9']].mean().mean()

print(f"Average sales in control group: {control_sales_mean}")
print(f"Average sales in test group: {test_sales_mean}")

```

    Average sales in control group: 16.859364489248996
    Average sales in test group: 17.733008203642736
    


```python
# Check for missing values in the sales columns
print(data[['2023/1', '2023/2', '2023/3', '2023/4', '2023/5', 
            '2023/6', '2023/7', '2023/8', '2023/9']].isnull().sum())


```

    2023/1    4117
    2023/2    3968
    2023/3    3401
    2023/4    2895
    2023/5    4036
    2023/6    4267
    2023/7    3789
    2023/8    4027
    2023/9    4224
    dtype: int64
    


```python
# Remove rows with missing values in the sales columns
control_group_clean = control_group.dropna(subset=['2023/1', '2023/2', '2023/3', '2023/4', '2023/5', 
                                                   '2023/6', '2023/7', '2023/8', '2023/9'])

test_group_clean = test_group.dropna(subset=['2023/1', '2023/2', '2023/3', '2023/4', '2023/5', 
                                             '2023/6', '2023/7', '2023/8', '2023/9'])

```


```python
# Flatten the cleaned sales data
control_sales_clean = control_group_clean[['2023/1', '2023/2', '2023/3', '2023/4', '2023/5', 
                                           '2023/6', '2023/7', '2023/8', '2023/9']].values.flatten()

test_sales_clean = test_group_clean[['2023/1', '2023/2', '2023/3', '2023/4', '2023/5', 
                                     '2023/6', '2023/7', '2023/8', '2023/9']].values.flatten()

# Perform the t-test on the cleaned data
t_stat, p_value = stats.ttest_ind(control_sales_clean, test_sales_clean)

print(f"T-statistic: {t_stat}")
print(f"P-value: {p_value}")

```

    T-statistic: -0.9540420893045157
    P-value: 0.3405385674357224
    

# "Sales Trends Analysis: Effect of Promotions on Consumer Behavior


```python
import matplotlib.pyplot as plt
import seaborn as sns

# Set the figure size and style
plt.figure(figsize=(10, 6))
sns.set(style="whitegrid")

# Monthly columns for 2023
months = ['2023/1', '2023/2', '2023/3', '2023/4', '2023/5', '2023/6', '2023/7', '2023/8', '2023/9']

# Calculate average sales per month for both groups
control_avg_sales = control_group_clean[months].mean()
test_avg_sales = test_group_clean[months].mean()

# Plot the sales trends
plt.plot(months, control_avg_sales, label='Control Group (No Promotion)', marker='o', linestyle='-', color='b')
plt.plot(months, test_avg_sales, label='Test Group (With Promotion)', marker='o', linestyle='-', color='r')

# Adding titles and labels
plt.title('Sales Trends: Control Group vs. Test Group', fontsize=14)
plt.xlabel('Months', fontsize=12)
plt.ylabel('Average Sales', fontsize=12)

# Add legend
plt.legend()

# Rotate x-axis labels for better readability
plt.xticks(rotation=45)

# Show the plot
plt.tight_layout()
plt.show()

```


    
![png](output_81_0.png)
    


# "Sales Distribution Comparison: Control vs. Test Group"



```python
import matplotlib.pyplot as plt
import seaborn as sns

# Set the figure size and style
plt.figure(figsize=(10, 6))
sns.set(style="whitegrid")

# Monthly columns for 2023
months = ['2023/1', '2023/2', '2023/3', '2023/4', '2023/5', '2023/6', '2023/7', '2023/8', '2023/9']

# Calculate average sales per month for both groups
control_avg_sales = control_group_clean[months].mean()
test_avg_sales = test_group_clean[months].mean()

# Plot the sales trends
plt.plot(months, control_avg_sales, label='Control Group (No Promotion)', marker='o', linestyle='-', color='b')
plt.plot(months, test_avg_sales, label='Test Group (With Promotion)', marker='o', linestyle='-', color='r')

# Adding titles and labels
plt.title('Sales Trends: Control Group vs. Test Group', fontsize=14)
plt.xlabel('Months', fontsize=12)
plt.ylabel('Average Sales', fontsize=12)

# Add legend
plt.legend()

# Rotate x-axis labels for better readability
plt.xticks(rotation=45)

# Show the plot
plt.tight_layout()
plt.show()

```


    
![png](output_83_0.png)
    



```python
# Interpret the p-value
alpha = 0.05  # Significance level

if p_value < alpha:
    conclusion = "Reject the null hypothesis: There is a significant difference in sales between control and test groups."
else:
    conclusion = "Fail to reject the null hypothesis: There is no significant difference in sales between control and test groups."

print("T-test Conclusion:", conclusion)

# Add a brief summary of the findings
summary = f"""
Average Sales in Control Group: {control_sales_mean:.2f}
Average Sales in Test Group: {test_sales_mean:.2f}

Conclusion: {conclusion}
"""

print(summary)

```

    T-test Conclusion: Fail to reject the null hypothesis: There is no significant difference in sales between control and test groups.
    
    Average Sales in Control Group: 16.86
    Average Sales in Test Group: 17.73
    
    Conclusion: Fail to reject the null hypothesis: There is no significant difference in sales between control and test groups.
    
    


```python
# Additional Distribution Plot
plt.figure(figsize=(10, 6))
plt.hist(control_sales_clean, bins=30, alpha=0.5, label='Control Group (No Promotion)', color='blue')
plt.hist(test_sales_clean, bins=30, alpha=0.5, label='Test Group (With Promotion)', color='red')
plt.title('Sales Distribution: Control vs. Test Group')
plt.xlabel('Sales')
plt.ylabel('Frequency')
plt.legend()
plt.grid()
plt.show()

```


    
![png](output_85_0.png)
    



```python
# Generate a summary report
summary = {
    "Control Group Average Sales": control_sales_mean,
    "Test Group Average Sales": test_sales_mean,
    "T-statistic": t_stat,
    "P-value": p_value,
    "Conclusion": "Fail to reject the null hypothesis: No significant difference."
}

# Convert to DataFrame for better visualization
summary_df = pd.DataFrame(summary.items(), columns=["Metric", "Value"])
print(summary_df)

```

                            Metric  \
    0  Control Group Average Sales   
    1     Test Group Average Sales   
    2                  T-statistic   
    3                      P-value   
    4                   Conclusion   
    
                                                   Value  
    0                                          16.859364  
    1                                          17.733008  
    2                                          -0.954042  
    3                                           0.340539  
    4  Fail to reject the null hypothesis: No signifi...  
    

# Generate the Summary DataFrame


```python
import matplotlib.pyplot as plt

# Create a figure
fig, ax = plt.subplots(figsize=(8, 4))  # Set the size of the figure

# Hide axes
ax.axis('tight')
ax.axis('off')

# Create the table
table = ax.table(cellText=summary_df.values, colLabels=summary_df.columns, cellLoc='center', loc='center')

# Set font size for the table
table.auto_set_font_size(False)
table.set_fontsize(12)

# Adjust the column width
table.scale(1.2, 1.2)

# Title for the table
plt.title('A/B Testing Summary Report', fontsize=14)
plt.show()

```


    
![png](output_88_0.png)
    


# Average Sales Comparison Bar Chart
A bar chart can clearly show the average sales for both the control and test groups.


```python
import matplotlib.pyplot as plt

# Create a bar chart to compare average sales
labels = ['Control Group', 'Test Group']
averages = [control_sales_mean, test_sales_mean]

plt.figure(figsize=(8, 5))
plt.bar(labels, averages, color=['blue', 'red'], alpha=0.7)
plt.ylabel('Average Sales')
plt.title('Average Sales Comparison: Control vs Test Group')
plt.ylim(0, max(averages) + 5)  # Adjust y-axis for better visibility
plt.axhline(y=averages[0], color='blue', linestyle='--', label='Control Mean')
plt.axhline(y=averages[1], color='red', linestyle='--', label='Test Mean')
plt.legend()
plt.show()

```


    
![png](output_90_0.png)
    


# T-test Results Visualization
Visualizing the distributions of sales can give insights into the data spread and significance of the results.


```python
import seaborn as sns

plt.figure(figsize=(10, 6))
sns.histplot(control_sales_clean, bins=20, color='blue', label='Control Group', kde=True, stat='density', alpha=0.5)
sns.histplot(test_sales_clean, bins=20, color='red', label='Test Group', kde=True, stat='density', alpha=0.5)
plt.title('Sales Distribution: Control vs Test Group')
plt.xlabel('Sales')
plt.ylabel('Density')
plt.legend()
plt.show()

```


    
![png](output_92_0.png)
    


# Boxplot of Sales Data
A boxplot can show the median, quartiles, and potential outliers in your sales data.


```python
plt.figure(figsize=(10, 6))
sns.boxplot(data=[control_sales_clean, test_sales_clean], palette=['blue', 'red'])
plt.xticks([0, 1], ['Control Group', 'Test Group'])
plt.ylabel('Sales')
plt.title('Boxplot of Sales: Control vs Test Group')
plt.show()

```


    
![png](output_94_0.png)
    


# Sales Trends Over Time


```python
# Enhanced sales trends with annotations
plt.figure(figsize=(10, 6))
sns.set(style="whitegrid")

plt.plot(months, control_avg_sales, label='Control Group (No Promotion)', marker='o', linestyle='-', color='b')
plt.plot(months, test_avg_sales, label='Test Group (With Promotion)', marker='o', linestyle='-', color='r')

plt.title('Sales Trends: Control Group vs. Test Group', fontsize=14)
plt.xlabel('Months', fontsize=12)
plt.ylabel('Average Sales', fontsize=12)
plt.legend()
plt.xticks(rotation=45)
plt.axhline(y=control_sales_mean, color='blue', linestyle='--', label='Control Mean')
plt.axhline(y=test_sales_mean, color='red', linestyle='--', label='Test Mean')
plt.legend()
plt.tight_layout()
plt.show()

```


    
![png](output_96_0.png)
    



```python
df_clean.head()  # To view the first few rows of df_clean
monthly_sales.head()  # To view the first few rows of monthly_sales

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2022/4</td>
      <td>82563.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2022/6</td>
      <td>96373.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023/3</td>
      <td>81792.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2023/4</td>
      <td>146273.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>sales_diff_2022</td>
      <td>13810.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
%whos

```

    Variable                   Type                        Data/Info
    ----------------------------------------------------------------
    ARIMA                      type                        <class 'statsmodels.tsa.arima.model.ARIMA'>
    actual_date_column_name    str                         your_actual_date_column_name
    alpha                      float                       0.05
    averages                   list                        n=2
    ax                         Axes                        Axes(0.125,0.11;0.775x0.77)
    bottom_stores              DataFrame                        store_id  sales_diff<...> -3.666667   581.818182  
    classify_product           function                    <function classify_product at 0x0000022F3616AB60>
    conclusion                 str                         Fail to reject the null h<...> control and test groups.
    confidence_intervals       DataFrame                                lower sales <...>6493.820683  87998.381218
    control_avg_sales          Series                      2023/1    18.578947\n2023<...>13.947368\ndtype: float64
    control_group              DataFrame                        item  store_id  2023<...>n[2701 rows x 24 columns]
    control_group_clean        DataFrame                        item  store_id  2023<...>n\n[19 rows x 24 columns]
    control_sales              ndarray                     6857: 6857 elems, type `float64`, 54856 bytes
    control_sales_clean        ndarray                     171: 171 elems, type `float64`, 1368 bytes
    control_sales_mean         float64                     16.859364489248996
    correlation_matrix         DataFrame                             store_id    202<...>54784  0.647889  1.000000
    d                          int                         1
    data                       DataFrame                        item  store_id  2023<...>n[5393 rows x 23 columns]
    data_melted                DataFrame                              item  store_id<...>[113253 rows x 3 columns]
    date_columns               list                        n=4
    demand_data                DataFrame                     item  total_demand_2023<...>  -1420.0     -110.077519
    df                         DataFrame                        item  store_id  2023<...>n[5393 rows x 23 columns]
    df_clean                   DataFrame                        item  store_id  2023<...>\n[5393 rows x 8 columns]
    fig                        Figure                      Figure(800x400)
    forecast                   PredictionResultsWrapper    <statsmodels.tsa.statespa<...>ct at 0x0000022F404C1C50>
    forecast_df                DataFrame                               Forecasted Sa<...>3-09-30               NaN
    forecast_index             DatetimeIndex               DatetimeIndex(['2023-04-3<...>atetime64[ns]', freq='M')
    forecast_mean              Series                      2023-10-31    22266.87998<...>cted_mean, dtype: float64
    forecast_steps             int                         6
    high_demand_products       DataFrame                     item  total_demand_2023<...>   -189.0      -26.177285
    highest_sales_diff_2022    DataFrame                         store_id  sales_dif<...>     633            309.0
    highest_sales_diff_2023    DataFrame                         store_id  sales_dif<...>     416           1500.0
    item_demand                DataFrame                   Empty DataFrame\nColumns:<...>les_diff_2022]\nIndex: []
    labels                     list                        n=2
    low_demand_products        DataFrame                     item  total_demand_2023<...>   8442.0      693.103448
    lowest_sales_diff_2022     DataFrame                         store_id  sales_dif<...>     225           -287.0
    lowest_sales_diff_2023     DataFrame                         store_id  sales_dif<...>     412           -350.0
    market_growth_threshold    float                       283.84676516721714
    market_share_threshold     float                       0.07903878661931421
    max_lags                   int                         5
    melted_df                  DataFrame                         item  store_id     <...>n[32358 rows x 4 columns]
    missing_percent            Series                      item         0.000000\nst<...>74.670870\ndtype: float64
    model                      ARIMA                       <statsmodels.tsa.arima.mo<...>ct at 0x0000022F3B550490>
    model_fit                  ARIMAResultsWrapper         <statsmodels.tsa.arima.mo<...>ct at 0x0000022F3899D950>
    monthly_demand             DataFrame                   store_id  1     2     3  <...>\n[8 rows x 1032 columns]
    monthly_sales              DataFrame                                 date     sa<...>sales_diff_2023   64481.0
    months                     list                        n=9
    non_numeric_cols           Index                       Index(['item'], dtype='object')
    np                         module                      <module 'numpy' from 'C:\<...>ges\\numpy\\__init__.py'>
    numeric_cols               Index                       Index(['store_id', '2023/<...>2022/6'], dtype='object')
    numeric_columns            DataFrame                         store_id  2023/3  2<...>\n[5393 rows x 5 columns]
    p                          int                         1
    p_value                    float64                     0.3405385674357224
    p_value_clean              float64                     0.29751837101319606
    pd                         module                      <module 'pandas' from 'C:<...>es\\pandas\\__init__.py'>
    plot_acf                   function                    <function plot_acf at 0x0000022F39A476A0>
    plot_pacf                  function                    <function plot_pacf at 0x0000022F39A45760>
    plt                        module                      <module 'matplotlib.pyplo<...>\\matplotlib\\pyplot.py'>
    q                          int                         1
    residuals                  Series                      date\n2022-01-31    13237<...>\nFreq: M, dtype: float64
    sales_diff_by_item_store   DataFrame                        item  store_id  sale<...>\n[5393 rows x 4 columns]
    sales_diff_summary         DataFrame                     item  sales_diff_2023  <...>0.302326         3.000000
    seasonal_demand            DataFrame                        item  store_id  2023<...>\n[5393 rows x 8 columns]
    selected_item              str                         ItemName
    sm                         module                      <module 'statsmodels.api'<...>es\\statsmodels\\api.py'>
    sns                        module                      <module 'seaborn' from 'C<...>s\\seaborn\\__init__.py'>
    stats                      module                      <module 'scipy.stats' fro<...>ipy\\stats\\__init__.py'>
    store_sales                DataFrame                         store_id  sales_dif<...>\n[1032 rows x 6 columns]
    summary                    dict                        n=5
    summary_df                 DataFrame                                           M<...>pothesis: No signifi...  
    t_stat                     float64                     -0.9540420893045157
    t_stat_clean               float64                     -1.0418092281372366
    table                      Table                       <matplotlib.table.Table o<...>ct at 0x0000022F491BDE10>
    test_avg_sales             Series                      2023/1    24.028571\n2023<...>18.342857\ndtype: float64
    test_group                 DataFrame                        item  store_id  2023<...>n[2692 rows x 24 columns]
    test_group_clean           DataFrame                        item  store_id  2023<...>n\n[35 rows x 24 columns]
    test_sales                 ndarray                     6956: 6956 elems, type `float64`, 55648 bytes
    test_sales_clean           ndarray                     315: 315 elems, type `float64`, 2520 bytes
    test_sales_mean            float64                     17.733008203642736
    top_stores                 DataFrame                        store_id  sales_diff<...>-1.833333 -13190.909091  
    total_sales                DataFrame                     item  sales_diff_2023  <...>  Dog  \n7          Dog  
    


```python
print(df_clean.columns)

```

    Index(['item', 'store_id', '2023/3', '2023/4', '2022/4', '2022/6',
           'sales_diff_2023', 'sales_diff_2022'],
          dtype='object')
    


```python
# Melt the DataFrame to reshape it so that the '2023/3', '2023/4', etc. become part of a 'date' column
cleaned_df = pd.melt(df_clean, id_vars=['item', 'store_id'], var_name='date', value_name='sales')

# Remove rows where the 'date' column has non-date values
cleaned_df = cleaned_df[cleaned_df['date'].str.match(r'^\d{4}/\d{1,2}$')]

# Save cleaned data to CSV
cleaned_df.to_csv('cleaned_data.csv', index=False)

```


```python
cleaned_df.to_csv('cleaned_data.csv', index=False)

```


```python

```
